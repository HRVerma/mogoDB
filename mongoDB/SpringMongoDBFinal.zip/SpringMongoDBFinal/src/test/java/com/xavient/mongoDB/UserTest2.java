package com.xavient.mongoDB;

import java.util.List;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.GenericXmlApplicationContext;
import org.springframework.data.mongodb.core.MongoOperations;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.data.mongodb.core.query.Update;

import com.xavient.mongoDB.entity.Users;

public class UserTest2 {

	private static ApplicationContext ctx;

	public static void main(String[] args) {

		// For XML
		ctx = new GenericXmlApplicationContext("springConfigMongoDB.xml");

		//ctx = new AnnotationConfigApplicationContext(SpringMongoConfig.class);
		MongoOperations mongoOperation = (MongoOperations) ctx.getBean("mongoTemplate");
		
		//save
		//save(new Users(1, "Ram", 20, "N"));
		
		// query to search user
		Query searchUserQuery = new Query(Criteria.where("name").is("Ram"));

		// find the saved user again.
		Users savedUser = mongoOperation.findOne(searchUserQuery, Users.class);
		System.out.println("1. find - savedUser : " + savedUser);

		// update password
		mongoOperation.updateFirst(searchUserQuery,
	                         Update.update("status", "U"),Users.class);

		// find the updated user object
		Users updatedUser = mongoOperation.findOne(searchUserQuery, Users.class);

		System.out.println("2 updatedUser : " + updatedUser);

		// delete
		//mongoOperation.remove(searchUserQuery, Users.class);

		// List, it should be empty now.
		List<Users> listUser = mongoOperation.findAll(Users.class);
		System.out.println("3. Number of user = " + listUser.size());


		for (Users user : listUser) {
			System.out.println("Id : " + user.getId() 
					+ ",    Name:" + user.getName() 
					+ ",    age : "+user.getAge()
					+ ",    Status : "+user.getStatus() );
		}
	}
}
