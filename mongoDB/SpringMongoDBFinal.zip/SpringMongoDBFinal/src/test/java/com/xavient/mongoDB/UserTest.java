package com.xavient.mongoDB;

import java.util.List;

import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import com.xavient.mongoDB.config.MongoDBConfig;
import com.xavient.mongoDB.entity.Users;
import com.xavient.mongoDB.repository.UsersRepository;

public class UserTest {

	private static AnnotationConfigApplicationContext ctx;

	public static void main(String[] args) {

		ctx = new AnnotationConfigApplicationContext();
		ctx.register(MongoDBConfig.class);
		ctx.refresh();
		UsersRepository usersRepository = ctx.getBean(UsersRepository.class);
		Users ram = new Users(1, "Ram", 20, "A");
		Users shyam = new Users(2, "Shyam", 19, "N");
		Users mohan = new Users(3, "Mohan", 20, "A");
		Users krishn = new Users(4, "Krishn", 20, "N");

		// Delete if exists already
		// usersRepository.deleteAll();

		// Save employee
//		usersRepository.save(ram);
//		usersRepository.save(shyam);
//		usersRepository.save(mohan);
//		usersRepository.save(krishn);
		// Get employee By Name
		Users users = usersRepository.getUsersByName(shyam.getName());
		System.out.println("Id : " + users.getId() 
				+ ",    Name:" + users.getName() 
				+ ",    age : "+users.getAge()
				+ ",    Status : "+users.getStatus() );
		// Fetch all employee for the age
//		List<Users> usresList = usersRepository.getUsersByAge(20);
//		System.out.println("----employee for the age 20----");
//
//		for (Users user : usresList) {
//			System.out.println("Id : " + user.getId() 
//					+ ",    Name:" + user.getName() 
//					+ ",    age : "+user.getAge()
//					+ ",    Status : "+user.getStatus() );
//		}
	}
}
