package com.xavient.mongoDB.config;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.data.authentication.UserCredentials;
import org.springframework.data.mongodb.MongoDbFactory;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.SimpleMongoDbFactory;
import org.springframework.data.mongodb.repository.config.EnableMongoRepositories;

import com.mongodb.MongoClient;
import com.xavient.mongoDB.repository.UsersRepository;

/**
 * @MongoDbFactory: Create database instances. In our example, we are creating a database with the name concretepage.
 * @MongoClient: Using IP and port of MongoDB server, MongoClient create an instance for the client.
 * @UserCredentials: Provides the instance to set username and password of MongoDB server. By default both are blank.
 * @SimpleMongoDbFactory: Provides MongoDB instance using MongoClient, database name and UserCredentials.
 * @MongoTemplate: It has basic sets of operation for MongoDB.
 *  
 */

@Configuration
@EnableMongoRepositories(basePackages = "com.xavient.mongodb")
public class MongoDBConfig {

	private static final String  DB_NAME = "xavient";
	
	private static final String  DB_USERNAME = "";
	
	private static final String  DB_PASSWORD = "";
	
	@Autowired
	UsersRepository usersRepository;

	@Bean
	public MongoDbFactory mongoDbFactory() throws Exception {
		MongoClient mongoClient = new MongoClient("localhost", 27017);
		UserCredentials userCredentials = new UserCredentials(DB_USERNAME, DB_PASSWORD);
		return new SimpleMongoDbFactory(mongoClient, DB_NAME, userCredentials);
	}

	@Bean
	public MongoTemplate mongoTemplate() throws Exception {
		MongoTemplate mongoTemplate = new MongoTemplate(mongoDbFactory());
		return mongoTemplate;
	}
}
