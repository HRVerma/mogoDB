package com.xavient.mongoDB.repository;

import java.util.List;

import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.data.mongodb.repository.Query;
import org.springframework.stereotype.Component;

/**
 * Spring data provides MongoRepository 
 * using which we create our repository class to add required methods which retrieves data. 
 * Queries are written in BSON syntax. ?0 is used to get parameter value. If we want to filter property,
 * we can use value and fields keys. Value is which we will pass as input and fields 
 * are those properties which will be populated. 
 *  
 */

import com.xavient.mongoDB.entity.Users;

@Component
public interface UsersRepository extends MongoRepository<Users, String> {

	@Query("{ 'name' : ?0 }")
	Users getUsersByName(String name);

	//Queries are written in BSON syntax. ?0 is used to get parameter value
	@Query(value = "{ 'age' : ?0}", fields = "{ 'name' : 'ravi', 'id' : 1}")
	List<Users> getUsersByAge(int age);
	
}
