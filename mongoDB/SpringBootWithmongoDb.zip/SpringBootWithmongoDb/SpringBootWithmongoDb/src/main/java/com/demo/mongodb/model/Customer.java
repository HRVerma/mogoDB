package com.demo.mongodb.model;

import java.util.List;

public class Customer {
	private String id;
	private String name;
	private String age;
	private String salary;
	private List<StudentWithId> listOfStudentWithId;
	
	public Customer(){}

	public Customer(String id, String name, String age, String salary,List<StudentWithId> listOfStudentWithId) {
		super();
		this.id = id;
		this.listOfStudentWithId = listOfStudentWithId;
		this.name = name;
		this.age = age;
		this.salary = salary;
	}
	
	@Override
	public String toString() {
		return String.format("Student[name=%s, age='%s', salary='%s']", name, age, salary);
	}
	
	/**
	 * @return the listOfStudentWithId
	 */
	public List<StudentWithId> getListOfStudentWithId() {
		return listOfStudentWithId;
	}

	/**
	 * @param listOfStudentWithId the listOfStudentWithId to set
	 */
	public void setListOfStudentWithId(List<StudentWithId> listOfStudentWithId) {
		this.listOfStudentWithId = listOfStudentWithId;
	}
	
	/**
	 * @return the id
	 */
	public String getId() {
		return id;
	}

	/**
	 * @param id
	 *            the id to set
	 */
	public void setId(String id) {
		this.id = id;
	}

	/**
	 * @return the name
	 */
	public String getName() {
		return name;
	}

	/**
	 * @param name
	 *            the name to set
	 */
	public void setName(String name) {
		this.name = name;
	}

	/**
	 * @return the age
	 */
	public String getAge() {
		return age;
	}

	/**
	 * @param age
	 *            the age to set
	 */
	public void setAge(String age) {
		this.age = age;
	}

	/**
	 * @return the salary
	 */
	public String getSalary() {
		return salary;
	}

	/**
	 * @param salary
	 *            the salary to set
	 */
	public void setSalary(String salary) {
		this.salary = salary;
	}
}
