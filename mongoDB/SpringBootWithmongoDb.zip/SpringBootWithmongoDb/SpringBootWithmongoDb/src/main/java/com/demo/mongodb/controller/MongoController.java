package com.demo.mongodb.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.demo.mongodb.dao.CustomerRepository;
import com.demo.mongodb.model.Customer;

@RestController
public class MongoController {

	/*@Autowired
	private StudentRepository repository;*/

	@Autowired
	private CustomerRepository customerRepository;

	@RequestMapping(method = RequestMethod.GET, value = "/test", produces = MediaType.TEXT_PLAIN_VALUE)
	public String test() {
		return "Mongo DB App is running";
	}

	@RequestMapping(method = RequestMethod.POST, value = "/saveCustomer", produces = MediaType.TEXT_PLAIN_VALUE, consumes = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<String> saveCustomer(@RequestBody Customer customer) {
		customerRepository.save(customer);
		return new ResponseEntity<String>("Customer Saved Sucessfully", HttpStatus.OK);
	}

	@RequestMapping(method = RequestMethod.GET, value = "/findCustomerByNames", produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<List<Customer>> findCustomerByNames(@RequestParam String name) {
		return new ResponseEntity<List<Customer>>(customerRepository.findByName(name), HttpStatus.OK);
	}

	@RequestMapping(method = RequestMethod.GET, value = "/findCustomerById", produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<Customer> findCustomerById(@RequestParam String id) {
		return new ResponseEntity<Customer>(customerRepository.findOne(id), HttpStatus.OK);
	}

	@RequestMapping(method = RequestMethod.DELETE, value = "/deleteCustomer", produces = MediaType.TEXT_PLAIN_VALUE)
	public ResponseEntity<String> deleteCustomer(@RequestParam String id) {
		String response = "";
		if (customerRepository.findOne(id) != null) {
			customerRepository.delete(customerRepository.findOne(id));
			response = "Customer delete Sucessfully.";
		} else {
			response = "Customer not found in the Database.";
		}
			
		return new ResponseEntity<String>(response, HttpStatus.OK);
	}

	@RequestMapping(method = RequestMethod.GET, value = "/getAllCustomers", produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<List<Customer>> getAllCustomers() {
		return new ResponseEntity<List<Customer>>(customerRepository.findAll(), HttpStatus.OK);
	}

	@RequestMapping(method = RequestMethod.DELETE, value = "/deleteAllCustomer", produces = MediaType.TEXT_PLAIN_VALUE)
	public ResponseEntity<String> deleteAllCustomer() {
		customerRepository.deleteAll();
		return new ResponseEntity<String>("Delete all sucess", HttpStatus.OK);
	}
}
