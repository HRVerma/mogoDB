package com.demo.mongodb.dao;

import java.util.List;

import org.springframework.data.mongodb.repository.MongoRepository;

import com.demo.mongodb.model.StudentWithId;

public interface StudentRepository extends MongoRepository<StudentWithId, String> {

	public List<StudentWithId> findByName(String name);

	public List<StudentWithId> findBySalary(String salary);

}