package com.demo.mongodb.app;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.data.mongodb.repository.config.EnableMongoRepositories;

import springfox.documentation.swagger2.annotations.EnableSwagger2;

import com.demo.mongodb.controller.MongoController;
import com.demo.mongodb.dao.CustomerRepository;
import com.demo.mongodb.dao.StudentRepository;

@Configuration
@ComponentScan(basePackages = { "com.demo.mongodb" }, basePackageClasses = { MongoController.class })
@EnableAutoConfiguration
@EnableMongoRepositories(basePackages = { "com.demo.mongodb.dao" })
@EnableSwagger2
public class MongoDBCrudApp /* implements CommandLineRunner */{

	/*@Autowired
	private StudentRepository repository;

	@Autowired
	private CustomerRepository customerRepository;*/

	public static void main(String[] args) {
		SpringApplication.run(MongoDBCrudApp.class, args);
	}

	/*
	 * @Override public void run(String... args) throws Exception {
	 * 
	 * repository.deleteAll();
	 * 
	 * // save a couple of customers repository.save(new StudentWithId("1",
	 * "Alice1", "50", "15222")); repository.save(new StudentWithId("2", "Bob1",
	 * "40", "20000"));
	 * 
	 * // fetch all customers
	 * System.out.println("Customers found with findAll():");
	 * System.out.println("-------------------------------"); for (StudentWithId
	 * customer : repository.findAll()) { System.out.println(customer); }
	 * System.out.println();
	 * 
	 * // fetch an individual customer
	 * System.out.println("Customer found with findByName('Alice'):");
	 * System.out.println("--------------------------------");
	 * //System.out.println(repository.findByName("Alice"));
	 * 
	 * for (StudentWithId customer : repository.findByName("Alice")) {
	 * System.out.println(customer); }
	 * 
	 * 
	 * System.out.println("Customers found with findBySalary('20000'):");
	 * System.out.println("--------------------------------"); for
	 * (StudentWithId customer : repository.findBySalary("20000")) {
	 * System.out.println(customer); }
	 * 
	 * System.out.println("For Customers"); // save a couple of customers
	 * customerRepository.save(new Customer("Aviral", "500", "12000"));
	 * customerRepository.save(new Customer("Anil Rautela", "400", "25000"));
	 * 
	 * // fetch all customers
	 * System.out.println("Customers found with findAll():");
	 * System.out.println("-------------------------------"); for (Customer
	 * customer : customerRepository.findAll()) { System.out.println(customer);
	 * } System.out.println();
	 * 
	 * // fetch an individual customer
	 * System.out.println("Customer found with findByName('Aviral'):");
	 * System.out.println("--------------------------------");
	 * //System.out.println(repository.findByName("Alice"));
	 * 
	 * for (Customer customer : customerRepository.findByName("Aviral")) {
	 * System.out.println(customer); }
	 * 
	 * 
	 * System.out.println("Customers found with findBySalary('20000'):");
	 * System.out.println("--------------------------------"); for (Customer
	 * customer : customerRepository.findBySalary("25000")) {
	 * System.out.println(customer); }
	 * 
	 * }
	 */
}
