package com.demo.mongodb.dao;

import java.util.List;

import org.springframework.data.mongodb.repository.MongoRepository;

import com.demo.mongodb.model.Customer;

public interface CustomerRepository extends MongoRepository<Customer, String> {

	public List<Customer> findByName(String name);

	public List<Customer> findBySalary(String salary);

}